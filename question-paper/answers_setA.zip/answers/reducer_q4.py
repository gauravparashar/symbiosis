import sys
x = 0
for line in sys.stdin:
	line = line.strip()
	year,temp = line.split("\t")
	
	if x == 0:
		mtemp = temp
		myear = year
		x = x + 1

	if mtemp > temp:
		mtemp =  temp
		myear = year
		
print "%s\t%s" %(mtemp,myear)
