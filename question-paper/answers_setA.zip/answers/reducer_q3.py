import sys

found = 0

for line in sys.stdin:
	line = line.strip()
	lst = line.split(' ')
	for w in lst:
		if found == 2:
			print "%s" %(w)
			found = 0
			break

		if found == 1:
			print "%s" %(w)
			found = found + 1


		if w == 'Author:':
			found = 1
#			print "%s\t%s" %(w)
