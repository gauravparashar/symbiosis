import sys

for line in sys.stdin:
	word,count = line.split('\t')
#	print(word)
	if word == 'Ireland':
		print("Story is based in Ireland")
	if word == 'Afganistan':
		print("Story is based in Afganistan")
	if word == 'France':
		print("Story is based in France")
	if word == 'Angola':
		print("Story is based in Angloa")
	if word =='India':
		print("Story is based in India")
