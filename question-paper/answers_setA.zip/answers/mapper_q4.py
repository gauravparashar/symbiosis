import sys

for line in sys.stdin:
	line = line.strip()
	lst = line.split(",")
	print "%s\t%s" %(lst[0],lst[2])
