import sys

d = {}
total = 0
for line in sys.stdin:
	line = line.strip()
	word,count = line.split('\t')
	count = int(count)
	if word in d:
		d[word] = d[word] + 1
	else:
		d[word]=count

for k in d.keys():
	#print "%s\t%s " %(k,d[k])
	total = total + d[k]
print("Total Words=",total)
