import sys

words = []

for line in sys.stdin:
	line = line.strip()
	words = line.split(' ')
	for w in words:
		print "%s\t%s" %(w,1)
