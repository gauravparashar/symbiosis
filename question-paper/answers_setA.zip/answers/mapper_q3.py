import sys
for line in sys.stdin:
	line = line.strip()
	lst = line.split(" ")
	for w in lst:
		print "%s" %(w)
